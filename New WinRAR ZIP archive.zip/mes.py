import nexmo

def send_sms(to, body):
    # Replace 'YOUR_API_KEY' and 'YOUR_API_SECRET' with your Nexmo credentials
    api_key = 'bd0777ec'
    api_secret = 'PRt2zyxMH2KWv3Me'

    client = nexmo.Client(key=api_key, secret=api_secret)

    from_number = '+917483565189'  # Replace with your sender number or alphanumeric sender ID

    sms = nexmo.Sms(client)

    response = sms.send_message({
        'from': from_number,
        'to': to,
        'text': body
    })

    message_id = response['messages'][0]['message-id']
    print(f"Message sent with ID: {message_id}")

def entry_message():
    mylist = ["Link1", "Link2", "Link3"]  # Replace with your actual links
    name = "izuku"
    slot_no = 3
    phone_number = '+917795395871'  # Replace with the recipient's phone number in international format
    url2 = mylist[slot_no - 1]
    message = f"Hello {name}, your allocated parking slot is {slot_no}"
    send_sms(phone_number, message)

def exit_message():
    amount = 35
    phone_number = '+917795395871'  # Replace with the recipient's phone number in international format
    message = f"Your parking fee is {amount}. Please pay it using the provided instructions."
    send_sms(phone_number, message)

# entry_message()
exit_message()
